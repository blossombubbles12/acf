"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";

const navItems = [
    { name: "Home", href: "/" },
    { name: "About Us", href: "/about" },
    { name: "Media Hub", href: "/media" },
    { name: "Events", href: "/events" },
    { name: "News", href: "/news" },
    { name: "Contact", href: "/contact" },
];

export function Header() {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const pathname = usePathname();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 20);
        };
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    // Close mobile menu on route change
    useEffect(() => {
        setIsMobileMenuOpen(false);
    }, [pathname]);

    return (
        <header
            className={cn(
                "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
                isScrolled
                    ? "bg-white/90 backdrop-blur-md shadow-sm border-gray-200 py-3"
                    : "bg-transparent border-transparent py-5"
            )}
        >
            <div className="container mx-auto px-4 flex items-center justify-between">
                {/* Logo */}
                <Link href="/" className="flex items-center gap-3 group">
                    <div className="relative w-12 h-12 flex-shrink-0">
                        <Image
                            src="/ckclogo.png"
                            alt="CKC Logo"
                            fill
                            className="object-contain"
                            priority
                        />
                    </div>
                    <div className="flex flex-col">
                        <span className={cn("font-serif font-bold leading-tight text-lg", isScrolled ? "text-primary" : "text-white")}>
                            CKC Class of '81
                        </span>
                        <span className={cn("text-xs font-medium uppercase tracking-wider", isScrolled ? "text-gray-600" : "text-white/80")}>
                            Excellence & Brotherhood
                        </span>
                    </div>
                </Link>

                {/* Desktop Nav */}
                <nav className="hidden md:flex items-center gap-8">
                    {navItems.map((item) => (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                                "text-sm font-medium transition-colors hover:text-accent relative py-1",
                                pathname === item.href
                                    ? "text-accent font-semibold"
                                    : isScrolled
                                        ? "text-gray-700"
                                        : "text-white/90"
                            )}
                        >
                            {item.name}
                            {pathname === item.href && (
                                <motion.span
                                    layoutId="underline"
                                    className="absolute left-0 bottom-0 w-full h-[2px] bg-accent"
                                />
                            )}
                        </Link>
                    ))}
                    <Link
                        href="/community/join"
                        className={cn(
                            "px-5 py-2 rounded-full text-sm font-semibold transition-all shadow-md hover:shadow-lg",
                            isScrolled
                                ? "bg-primary text-white hover:bg-primary/90"
                                : "bg-white text-primary hover:bg-white/90"
                        )}
                    >
                        Member Login
                    </Link>
                </nav>

                {/* Mobile Toggle */}
                <button
                    className="md:hidden p-2 text-current"
                    onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                >
                    {isMobileMenuOpen ? (
                        <X className={isScrolled ? "text-gray-800" : "text-white"} />
                    ) : (
                        <Menu className={isScrolled ? "text-gray-800" : "text-white"} />
                    )}
                </button>
            </div>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {isMobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="absolute top-full left-0 right-0 bg-white border-b border-gray-100 shadow-xl p-4 md:hidden"
                    >
                        <nav className="flex flex-col gap-4">
                            {navItems.map((item) => (
                                <Link
                                    key={item.href}
                                    href={item.href}
                                    className={cn(
                                        "block px-4 py-2 rounded-md text-base font-medium transition-colors",
                                        pathname === item.href
                                            ? "bg-primary/10 text-primary"
                                            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                                    )}
                                >
                                    {item.name}
                                </Link>
                            ))}
                            <div className="h-px bg-gray-100 my-2" />
                            <Link
                                href="/community/join"
                                className="block w-full text-center px-4 py-3 bg-primary text-white rounded-md font-semibold hover:bg-primary/90"
                            >
                                Member Login
                            </Link>
                        </nav>
                    </motion.div>
                )}
            </AnimatePresence>
        </header>
    );
}
