import Image from "next/image";
import Link from "next/link";
import { Facebook, Twitter, Linkedin, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
    return (
        <footer className="bg-navy text-primary-foreground py-12 border-t border-white/5">
            <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
                {/* Brand */}
                <div className="space-y-6">
                    <Link href="/" className="flex items-center gap-4">
                        <div className="relative w-16 h-16">
                            <Image
                                src="/ckclogo.png"
                                alt="CKC Logo"
                                fill
                                className="object-contain"
                            />
                        </div>
                        <div>
                            <h2 className="text-2xl font-serif font-bold text-white">
                                CKC Class of <span className="text-white/80">'81</span>
                            </h2>
                            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-accent">Excellence & Brotherhood</p>
                        </div>
                    </Link>
                    <p className="text-sm opacity-70 max-w-xs leading-relaxed font-medium">
                        United in brotherhood, guided by faith, and committed to excellence. Celebrating over 40 years of shared heritage.
                    </p>
                </div>

                {/* Quick Links */}
                <div className="space-y-6">
                    <h3 className="text-lg font-bold font-serif text-white/90">Quick Links</h3>
                    <ul className="space-y-3 text-sm">
                        <li><Link href="/about" className="text-white/60 hover:text-white transition-colors">About Us</Link></li>
                        <li><Link href="/executives" className="text-white/60 hover:text-white transition-colors">Executives & Committees</Link></li>
                        <li><Link href="/community" className="text-white/60 hover:text-white transition-colors">Members Directory</Link></li>
                        <li><Link href="/media" className="text-white/60 hover:text-white transition-colors">Media Hub</Link></li>
                        <li><Link href="/events" className="text-white/60 hover:text-white transition-colors">Events & Reunions</Link></li>
                    </ul>
                </div>

                {/* Contact */}
                <div className="space-y-6">
                    <h3 className="text-lg font-bold font-serif text-white/90">Contact Us</h3>
                    <ul className="space-y-4 text-sm">
                        <li className="flex items-start gap-4">
                            <MapPin className="w-5 h-5 text-accent shrink-0 mt-0.5" />
                            <span className="text-white/60">Christ the King College,<br />Onitsha, Anambra State</span>
                        </li>
                        <li className="flex items-center gap-4">
                            <Mail className="w-5 h-5 text-accent shrink-0" />
                            <a href="mailto:info@ckcalumniclass1981.org" className="text-white/60 hover:text-accent transition-colors">info@ckcalumniclass1981.org</a>
                        </li>
                        <li className="flex items-center gap-4">
                            <Phone className="w-5 h-5 text-accent shrink-0" />
                            <span className="text-white/60">+234 800 000 0000</span>
                        </li>
                    </ul>
                </div>

                {/* Social & Newsletter */}
                <div className="space-y-6">
                    <h3 className="text-lg font-bold font-serif text-white/90">Stay Connected</h3>
                    <div className="flex gap-4">
                        <a href="#" className="p-3 bg-white/5 text-white/60 rounded-xl hover:bg-accent hover:text-white transition-all">
                            <Facebook className="w-5 h-5" />
                        </a>
                        <a href="#" className="p-3 bg-white/5 text-white/60 rounded-xl hover:bg-accent hover:text-white transition-all">
                            <Twitter className="w-5 h-5" />
                        </a>
                        <a href="#" className="p-3 bg-white/5 text-white/60 rounded-xl hover:bg-accent hover:text-white transition-all">
                            <Linkedin className="w-5 h-5" />
                        </a>
                    </div>
                    <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest pt-6 border-t border-white/5">
                        &copy; {new Date().getFullYear()} CKC Alumni Class of 1981.
                    </p>
                </div>
            </div>
        </footer>
    );
}
