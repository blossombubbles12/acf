"use client";

import { useEffect, useState } from "react";
import { ShowcaseCarousel } from "./ShowcaseCarousel";
import { Newspaper, MessageSquare, ArrowRight, Clock } from "lucide-react";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import Image from "next/image";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";

interface Post {
    id: number;
    content: string;
    media: { type: string; url: string }[] | null;
    created_at: string;
}

export function PostsShowcase() {
    const { getRandomImage } = useCloudinaryPool();
    const [posts, setPosts] = useState<Post[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchPosts() {
            try {
                const res = await fetch("/api/posts");
                const data = await res.json();
                setPosts(Array.isArray(data) ? data : []);
            } catch (err) {
                console.error("Failed to fetch posts");
            } finally {
                setLoading(false);
            }
        }
        fetchPosts();
    }, []);

    if (loading) return null;
    if (posts.length === 0) return null;

    return (
        <ShowcaseCarousel
            title="Latest from the Brotherhood Feed"
            subtitle="Updates & Milestones"
            items={posts}
            viewAllHref="/news"
            columns={4}
            renderItem={(post) => {
                const firstMedia = post.media && post.media[0];
                return (
                    <div className="group bg-slate-50 rounded-[2.5rem] border border-gray-100 overflow-hidden hover:bg-white hover:shadow-2xl transition-all duration-500 h-full flex flex-col">
                        <div className="relative h-64 overflow-hidden">
                            <Image
                                src={firstMedia ? firstMedia.url : getRandomImage(post.id)}
                                alt="Post media"
                                fill
                                className="object-cover transition-transform duration-700 group-hover:scale-110"
                                unoptimized
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                        </div>
                        <div className="p-8 flex-grow flex flex-col">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-[10px] font-black">C</div>
                                <div>
                                    <p className="text-[10px] font-black text-gray-900 uppercase">Class Admin</p>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mt-1">
                                        {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
                                    </p>
                                </div>
                            </div>
                            <p className="text-gray-700 font-medium leading-relaxed mb-8 line-clamp-3">
                                {post.content}
                            </p>
                            <Link
                                href="/news"
                                className="mt-auto inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary hover:text-accent transition-colors"
                            >
                                View Discussions <MessageSquare className="w-3.5 h-3.5" />
                            </Link>
                        </div>
                    </div>
                );
            }}
        />
    );
}
