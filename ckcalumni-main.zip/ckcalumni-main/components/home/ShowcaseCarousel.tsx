"use client";

import React, { useRef, useEffect, useState } from "react";
import { motion, useScroll, useSpring, useTransform, useMotionValue } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ShowcaseCarouselProps {
    title: string;
    subtitle: string;
    items: any[];
    renderItem: (item: any, index: number) => React.ReactNode;
    viewAllHref: string;
    columns?: number;
}

export function ShowcaseCarousel({ title, subtitle, items, renderItem, viewAllHref, columns = 4 }: ShowcaseCarouselProps) {
    const scrollRef = useRef<HTMLDivElement>(null);
    const [canScrollLeft, setCanScrollLeft] = useState(false);
    const [canScrollRight, setCanScrollRight] = useState(true);

    const checkScroll = () => {
        if (scrollRef.current) {
            const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
            setCanScrollLeft(scrollLeft > 0);
            setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1);
        }
    };

    useEffect(() => {
        checkScroll();
        window.addEventListener("resize", checkScroll);
        return () => window.removeEventListener("resize", checkScroll);
    }, [items]);

    const scroll = (direction: "left" | "right") => {
        if (scrollRef.current) {
            const { clientWidth } = scrollRef.current;
            const scrollAmount = direction === "left" ? -clientWidth : clientWidth;
            scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
        }
    };

    return (
        <section className="py-24 bg-white overflow-hidden">
            <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
                    <div className="max-w-2xl">
                        <span className="text-[10px] font-black uppercase tracking-[0.5em] text-accent mb-4 block underline decoration-accent/30 underline-offset-8">
                            {subtitle}
                        </span>
                        <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 leading-tight">
                            {title}
                        </h2>
                    </div>
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => scroll("left")}
                            className={`p-4 rounded-full border transition-all ${canScrollLeft ? "border-primary text-primary hover:bg-primary hover:text-white" : "border-gray-100 text-gray-300 cursor-not-allowed"}`}
                            disabled={!canScrollLeft}
                        >
                            <ChevronLeft className="w-6 h-6" />
                        </button>
                        <button
                            onClick={() => scroll("right")}
                            className={`p-4 rounded-full border transition-all ${canScrollRight ? "border-primary text-primary hover:bg-primary hover:text-white" : "border-gray-100 text-gray-300 cursor-not-allowed"}`}
                            disabled={!canScrollRight}
                        >
                            <ChevronRight className="w-6 h-6" />
                        </button>
                    </div>
                </div>

                <div
                    ref={scrollRef}
                    onScroll={checkScroll}
                    className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-12"
                    style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                >
                    {items.map((item, index) => (
                        <div
                            key={index}
                            className={`shrink-0 snap-start w-[calc(50%-0.75rem)] sm:w-[calc(33.333%-1rem)] lg:w-[calc(100%/${columns}-1.25rem)]`}
                        >
                            {renderItem(item, index)}
                        </div>
                    ))}
                    {items.length === 0 && (
                        <div className="w-full py-20 text-center bg-slate-50 rounded-[3rem] border border-dashed border-gray-200">
                            <p className="text-gray-400 font-medium">Coming soon...</p>
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
}
