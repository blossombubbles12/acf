"use client";

import { useEffect, useState } from "react";
import { ShowcaseCarousel } from "./ShowcaseCarousel";
import { ImageIcon, Folder, Maximize2 } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { transformCloudinary } from "@/lib/cloudinary-client";

interface Album {
    name: string;
    path: string;
    count: number;
    cover: string | null;
}

export function GalleryShowcase() {
    const [albums, setAlbums] = useState<Album[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchAlbums() {
            try {
                const res = await fetch("/api/media/folders");
                const data = await res.json();
                setAlbums(Array.isArray(data) ? data : []);
            } catch (err) {
                console.error("Failed to fetch albums");
            } finally {
                setLoading(false);
            }
        }
        fetchAlbums();
    }, []);

    if (loading) return null;
    if (albums.length === 0) return null;

    return (
        <ShowcaseCarousel
            title="The Vault of Memories"
            subtitle="Gallery Archive"
            items={albums}
            viewAllHref="/media"
            columns={4}
            renderItem={(album) => (
                <Link
                    href={`/media/album/${album.name}`}
                    className="group relative block aspect-[3/4] rounded-[2rem] overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-700"
                >
                    {album.cover ? (
                        <Image
                            src={transformCloudinary(album.cover)}
                            alt={album.name}
                            fill
                            className="object-cover transition-transform duration-1000 group-hover:scale-110"
                            unoptimized
                        />
                    ) : (
                        <div className="h-full w-full bg-slate-100 flex items-center justify-center">
                            <ImageIcon className="w-12 h-12 text-slate-200" />
                        </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-navy/90 via-navy/20 to-transparent z-10" />
                    <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-20">
                        <div className="p-3 bg-white/20 backdrop-blur-md rounded-2xl border border-white/20 text-white">
                            <Maximize2 className="w-5 h-5" />
                        </div>
                    </div>
                    <div className="absolute inset-0 flex flex-col justify-end p-8 text-white z-20">
                        <div className="mb-4 flex items-center gap-2">
                            <Folder className="w-4 h-4 text-white/60" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-white/60">{album.count} items</span>
                        </div>
                        <h4 className="text-xl font-serif font-bold leading-tight group-hover:text-white transition-colors">{album.name}</h4>
                    </div>
                </Link>
            )}
        />
    );
}
