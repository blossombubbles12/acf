"use client";

import { useEffect, useState, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Loader2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";
import { transformCloudinary } from "@/lib/cloudinary-client";

interface HeroSlide {
    title: string;
    subtitle: string;
    description: string;
    ctaLabel: string;
    ctaHref: string;
    image?: string;
}

const HERO_CONTENT: HeroSlide[] = [
    {
        title: "A Legacy of Brotherhood",
        subtitle: "Founded in CKC, Forged by Time",
        description: "More than four decades later, our bond remains unbroken. We are a community of purpose, unity, and excellence.",
        ctaLabel: "Explore Our Journey",
        ctaHref: "/about",
    },
    {
        title: "The Class of 1981",
        subtitle: "Gentlemen of Honor and Excellence",
        description: "A network of distinguished professionals and leaders across the globe, united by a shared mission to give back.",
        ctaLabel: "Meet the Alumni",
        ctaHref: "/community",
    },
    {
        title: "Preserving Every Memory",
        subtitle: "A Visual Chronicle of Our Excellence",
        description: "Rediscover the milestones, the reunions, and the life-long friendships captured throughout our shared history.",
        ctaLabel: "Visit Media Hub",
        ctaHref: "/media",
    }
];

export function HeroCarousel() {
    const { images, loading: poolLoading } = useCloudinaryPool(10);
    const [slides, setSlides] = useState<HeroSlide[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [direction, setDirection] = useState(0);

    useEffect(() => {
        if (!poolLoading) {
            // Match content with images from the pool
            const enrichedSlides = HERO_CONTENT.map((content, idx) => ({
                ...content,
                image: transformCloudinary(images[idx % images.length]) || ""
            }));
            setSlides(enrichedSlides);
            setLoading(false);
        }
    }, [images, poolLoading]);

    const slideNext = useCallback(() => {
        setDirection(1);
        setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, [slides.length]);

    const slidePrev = useCallback(() => {
        setDirection(-1);
        setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
    }, [slides.length]);

    // Auto-play
    useEffect(() => {
        if (slides.length === 0) return;
        const interval = setInterval(slideNext, 8000);
        return () => clearInterval(interval);
    }, [slideNext, slides.length]);

    if (loading) return (
        <div className="h-screen flex items-center justify-center bg-navy">
            <Loader2 className="w-10 h-10 animate-spin text-white/20" />
        </div>
    );

    const variants = {
        enter: (direction: number) => ({
            x: direction > 0 ? 1000 : -1000,
            opacity: 0,
        }),
        center: {
            zIndex: 1,
            x: 0,
            opacity: 1,
        },
        exit: (direction: number) => ({
            zIndex: 0,
            x: direction < 0 ? 1000 : -1000,
            opacity: 0,
            transition: { duration: 0.5 }
        })
    };

    return (
        <section className="relative h-screen w-full overflow-hidden bg-primary">
            {/* Background Slides */}
            <AnimatePresence initial={false} custom={direction}>
                <motion.div
                    key={currentIndex}
                    custom={direction}
                    variants={variants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{
                        x: { type: "spring", stiffness: 300, damping: 30 },
                        opacity: { duration: 0.6 }
                    }}
                    className="absolute inset-0"
                >
                    {slides[currentIndex]?.image && (
                        <Image
                            src={slides[currentIndex].image!}
                            alt={slides[currentIndex].title}
                            fill
                            className="object-cover scale-105 animate-[ken-burns_20s_ease-in-out_infinite]"
                            priority
                            unoptimized
                        />
                    )}
                    {/* Gradients */}
                    <div className="absolute inset-0 bg-gradient-to-br from-navy/90 via-navy/40 to-black/80 z-10" />
                    <div className="absolute inset-0 bg-black/20 z-10" />
                </motion.div>
            </AnimatePresence>

            {/* Content Overlay */}
            <div className="relative z-20 h-full container mx-auto px-4 flex flex-col justify-center items-center">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentIndex}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.5 }}
                        className="w-full max-w-6xl"
                    >
                        <div className="grid lg:grid-cols-12 gap-12 items-center">
                            {/* Text Side */}
                            <div className="lg:col-span-7 text-left space-y-8 pt-20"> {/* Added pt-20 to move away from menu */}
                                <motion.div
                                    initial={{ opacity: 0, x: -50 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.2, duration: 0.6 }}
                                >
                                    <span className="inline-block px-4 py-2 rounded-full bg-accent/20 backdrop-blur-md text-accent text-[10px] sm:text-xs font-black uppercase tracking-[0.4em] border border-accent/30">
                                        Official Platform — Tagbo Boys
                                    </span>
                                </motion.div>

                                <div className="space-y-4">
                                    <motion.p
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.3, duration: 0.6 }}
                                        className="text-white/60 font-black uppercase tracking-[0.4em] text-xs sm:text-sm"
                                    >
                                        {slides[currentIndex].subtitle}
                                    </motion.p>
                                    <motion.h1
                                        initial={{ opacity: 0, y: 30 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.4, duration: 0.8 }}
                                        className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-[1.1] tracking-tighter italic"
                                    >
                                        {slides[currentIndex].title}
                                    </motion.h1>
                                </div>

                                <motion.p
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.5, duration: 0.6 }}
                                    className="text-white/80 text-lg md:text-xl font-medium max-w-xl leading-relaxed"
                                >
                                    {slides[currentIndex].description}
                                </motion.p>

                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.6, duration: 0.6 }}
                                    className="flex flex-col sm:flex-row gap-5 pt-4"
                                >
                                    <Link
                                        href={slides[currentIndex].ctaHref}
                                        className="px-10 py-5 bg-accent text-[#0a1128] rounded-full font-bold hover:bg-white transition-all flex items-center justify-center gap-3 shadow-2xl shadow-accent/20 group text-sm uppercase tracking-widest"
                                    >
                                        {slides[currentIndex].ctaLabel} <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                                    </Link>
                                    <Link
                                        href="/about"
                                        className="px-10 py-5 bg-white/10 backdrop-blur-md border border-white/20 text-white rounded-full font-bold hover:bg-white/20 transition-all text-sm uppercase tracking-widest flex items-center justify-center"
                                    >
                                        Our History
                                    </Link>
                                </motion.div>
                            </div>

                            {/* Decorative Visual Side (Hidden on Mobile) */}
                            <div className="hidden lg:block lg:col-span-5 relative h-[500px]">
                                <motion.div
                                    initial={{ scale: 0.8, opacity: 0, rotate: -5 }}
                                    animate={{ scale: 1, opacity: 1, rotate: 0 }}
                                    transition={{ delay: 0.4, duration: 1 }}
                                    className="w-full h-full rounded-[4rem] border border-white/10 p-4 bg-white/5 backdrop-blur-sm relative"
                                >
                                    <div className="w-full h-full rounded-[3.5rem] overflow-hidden relative">
                                        <Image
                                            src={slides[currentIndex].image!}
                                            alt="Creative Detail"
                                            fill
                                            className="object-cover"
                                            unoptimized
                                        />
                                        <div className="absolute inset-0 bg-primary/20 mix-blend-overlay" />
                                    </div>
                                    <div className="absolute -top-6 -right-6 w-32 h-32 bg-accent rounded-full blur-3xl opacity-20 animate-pulse" />
                                    <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-primary rounded-full blur-3xl opacity-20 animate-pulse delay-1000" />
                                </motion.div>
                            </div>
                        </div>
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Navigation Controls */}
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-30 flex items-center gap-8">
                <button
                    onClick={slidePrev}
                    className="p-3 bg-white/5 backdrop-blur-lg border border-white/10 text-white rounded-full hover:bg-white/10 transition-all"
                >
                    <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="flex gap-3">
                    {slides.map((_, idx) => (
                        <button
                            key={idx}
                            onClick={() => {
                                setDirection(idx > currentIndex ? 1 : -1);
                                setCurrentIndex(idx);
                            }}
                            className={`h-1.5 transition-all duration-500 rounded-full ${idx === currentIndex ? 'w-12 bg-white' : 'w-4 bg-white/20 hover:bg-white/40'}`}
                        />
                    ))}
                </div>

                <button
                    onClick={slideNext}
                    className="p-3 bg-white/5 backdrop-blur-lg border border-white/10 text-white rounded-full hover:bg-white/10 transition-all"
                >
                    <ChevronRight className="w-5 h-5" />
                </button>
            </div>

            <style jsx global>{`
        @keyframes ken-burns {
          0% { transform: scale(1); }
          50% { transform: scale(1.1); }
          100% { transform: scale(1); }
        }
      `}</style>
        </section>
    );
}
