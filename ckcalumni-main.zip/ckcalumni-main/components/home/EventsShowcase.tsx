"use client";

import { useEffect, useState } from "react";
import { ShowcaseCarousel } from "./ShowcaseCarousel";
import { Calendar, MapPin, Clock, ArrowRight } from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";
import Image from "next/image";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";
import { transformCloudinary } from "@/lib/cloudinary-client";

interface Event {
    id: number;
    title: string;
    description: string;
    date: string;
    time: string | null;
    location: string | null;
    image_url: string | null;
}

export function EventsShowcase() {
    const { getRandomImage } = useCloudinaryPool();
    const [events, setEvents] = useState<Event[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchEvents() {
            try {
                const res = await fetch("/api/events");
                const data = await res.json();
                setEvents(Array.isArray(data) ? data : []);
            } catch (err) {
                console.error("Failed to fetch events");
            } finally {
                setLoading(false);
            }
        }
        fetchEvents();
    }, []);

    if (loading) return null;
    if (events.length === 0) return null;

    return (
        <ShowcaseCarousel
            title="Class Reunions & Global Events"
            subtitle="Mark Your Calendars"
            items={events}
            viewAllHref="/events"
            columns={4}
            renderItem={(event) => (
                <div className="group bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500 h-full flex flex-col">
                    <div className="relative h-64 overflow-hidden">
                        <Image
                            src={transformCloudinary(event.image_url) || getRandomImage(event.id)}
                            alt={event.title}
                            fill
                            className="object-cover transition-transform duration-700 group-hover:scale-110"
                            unoptimized
                        />
                        <div className="absolute top-6 left-6 px-4 py-2 bg-white/90 backdrop-blur-md rounded-2xl shadow-xl">
                            <p className="text-[10px] font-black uppercase tracking-widest text-primary">
                                {format(new Date(event.date), "MMM d, yyyy")}
                            </p>
                        </div>
                    </div>
                    <div className="p-8 flex-grow flex flex-col">
                        <h4 className="text-xl font-serif font-bold text-gray-900 mb-4 line-clamp-2 min-h-[3.5rem] group-hover:text-primary transition-colors">
                            {event.title}
                        </h4>
                        <div className="space-y-3 mb-8">
                            <div className="flex items-center gap-2 text-gray-500 text-sm font-medium">
                                <MapPin className="w-4 h-4 text-accent" />
                                <span className="line-clamp-1">{event.location || "To be announced"}</span>
                            </div>
                            {event.time && (
                                <div className="flex items-center gap-2 text-gray-500 text-sm font-medium">
                                    <Clock className="w-4 h-4 text-accent" />
                                    <span>{event.time}</span>
                                </div>
                            )}
                        </div>
                        <Link
                            href="/events"
                            className="mt-auto inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary hover:text-accent transition-colors underline decoration-primary/20 underline-offset-4"
                        >
                            Read Details <ArrowRight className="w-3 h-3" />
                        </Link>
                    </div>
                </div>
            )}
        />
    );
}
