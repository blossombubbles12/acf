import { NextResponse } from 'next/server';
import cloudinary from '@/lib/cloudinary';

export async function GET() {
    try {
        // Search for all images in the 'ckcalumni' root and its subfolders
        const result = await cloudinary.search
            .expression('folder:ckcalumni/* AND resource_type:image')
            .sort_by('created_at', 'desc')
            .max_results(500)
            .execute();

        // Shuffle and pick 10 random images for the carousel
        const shuffled = result.resources
            .map((value: any) => ({ value, sort: Math.random() }))
            .sort((a: any, b: any) => a.sort - b.sort)
            .map(({ value }: any) => value)
            .slice(0, 10);

        return NextResponse.json(shuffled);
    } catch (error) {
        console.error('Featured media error:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
