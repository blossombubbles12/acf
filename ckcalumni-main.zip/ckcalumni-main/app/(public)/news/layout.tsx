import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Brotherhood News & Updates",
    description:
        "The latest news, announcements, and updates from the CKC Class of 1981 Alumni Association. Stay connected with your brothers.",
    openGraph: {
        title: "Brotherhood News | CKC Class of 1981",
        description:
            "Latest announcements, updates, and discussions from the CKC Class of 1981 Alumni Association.",
        url: "/news",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 News" }],
    },
};

export default function NewsLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
