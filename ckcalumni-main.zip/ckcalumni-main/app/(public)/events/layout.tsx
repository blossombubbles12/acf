import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Events",
    description:
        "Stay updated on all CKC Class of 1981 events — grand reunions, welfare meetings, and alumni gatherings happening across Nigeria and the globe.",
    openGraph: {
        title: "Events | CKC Class of 1981",
        description:
            "View upcoming and past events from the CKC Class of 1981 Alumni Association — reunions, galas, and brotherhood gatherings.",
        url: "/events",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 Events" }],
    },
};

export default function EventsLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
