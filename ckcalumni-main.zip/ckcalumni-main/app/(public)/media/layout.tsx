import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Media Gallery",
    description:
        "Explore the visual archive of the CKC Class of 1981. Browse photo albums and videos from our grand reunions, ceremonies, and brotherly gatherings spanning four decades.",
    openGraph: {
        title: "Media Gallery | CKC Class of 1981",
        description:
            "Browse the official photo and video archive of the CKC Class of 1981 — reunions, milestones, and memories.",
        url: "/media",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 Media" }],
    },
    twitter: {
        title: "Media Gallery | CKC Class of 1981",
        description:
            "Browse the official photo and video archive of the CKC Class of 1981.",
    },
};

export default function MediaLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
