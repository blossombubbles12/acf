import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Executives",
    description:
        "Meet the elected executives and officers of the CKC Class of 1981 Alumni Association — the proud leaders steering our legacy and brotherhood forward.",
    openGraph: {
        title: "Class Executives | CKC Class of 1981",
        description:
            "The elected leaders of the CKC Class of 1981 Alumni Association.",
        url: "/executives",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 Executives" }],
    },
};

export default function ExecutivesLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
