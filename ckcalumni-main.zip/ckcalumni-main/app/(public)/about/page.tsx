"use client";

import Image from "next/image";
import NextLink from "next/link";
import {
    Quote,
    History,
    Users,
    Heart,
    ShieldCheck,
    Target,
    Calendar,
    ChevronRight,
    Award,
    School
} from "lucide-react";
import { motion } from "framer-motion";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";

export default function AboutPage() {
    const { getRandomImage } = useCloudinaryPool();
    const fadeIn = {
        initial: { opacity: 0, y: 20 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 }
    };

    const pioneerMembers = [
        "Humphrey Ifeanyi Odiogor", "Emeka Anthony Opah", "Chibuzo Emma Okoh",
        "Uchenna Anigbata (Amichan)", "Mickey Moore", "Sony Nwankwo",
        "Ralph Nweke-Ezeudu", "Alex Ike Molokwu", "Eric Umeh (virtual)"
    ];

    const timeline = [
        { year: "1981", title: "The Graduation", desc: "Stepping out as gentlemen prepared to lead and shape the world." },
        { year: "2016", title: "The Stimulation", desc: "The death of Very Rev. Fr. N. C. Tagbo OON reunited the class in honor." },
        { year: "2017", title: "Maiden Meeting", desc: "8 members met at SWAN Centre, Lagos, birthing the official association." },
        { year: "2019", title: "Digital Regrouping", desc: "A new WhatsApp platform was created, growing membership to over 85." },
    ];

    return (
        <div className="bg-white selection:bg-primary/10">
            {/* Hero Section - High-End Aesthetic */}
            <section className="relative pt-40 pb-24 bg-[#0a1128] text-white">
                <div className="absolute inset-0 z-0 opacity-20">
                    <Image
                        src={getRandomImage(5)}
                        alt="Academic Heritage"
                        fill
                        className="object-cover"
                    />
                </div>
                <div className="container mx-auto px-4 relative z-10 text-center">
                    <motion.div {...fadeIn}>
                        <span className="inline-block px-3 py-1.5 sm:px-4 sm:py-2 rounded-full bg-accent/20 text-accent text-[9px] sm:text-[10px] font-black uppercase tracking-[0.3em] sm:tracking-[0.4em] mb-4 sm:mb-6 border border-accent/20">
                            Established 1981
                        </span>
                        <h1 className="text-4xl sm:text-5xl md:text-7xl font-serif font-bold mb-4 sm:mb-6 italic leading-tight">Bonds of <span className="font-light not-italic">Excellence</span></h1>
                        <p className="text-sm sm:text-base md:text-lg text-white/60 max-w-2xl mx-auto font-medium leading-relaxed">
                            A community of proud graduates from Christ the King College, Onitsha — men shaped by a shared heritage, timeless values, and purposeful friendship.
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* Our Story Intro */}
            <section className="py-20 md:py-32 relative">
                <div className="container mx-auto px-4">
                    <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                        <motion.div {...fadeIn} className="space-y-8 md:space-y-10">
                            <div className="inline-flex items-center gap-4 text-primary">
                                <span className="h-px w-12 bg-accent" />
                                <span className="text-sm font-black uppercase tracking-widest">Our Story</span>
                            </div>
                            <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 leading-tight">
                                Prepared to Lead, <br />
                                <span className="text-accent">Shaped to Serve.</span>
                            </h2>
                            <div className="space-y-6 text-lg text-gray-600 leading-relaxed font-medium">
                                <p>
                                    In 1981, we stepped out of CKC not just as students, but as gentlemen prepared to lead, serve, and shape the world. Across continents and careers, our journey has been diverse — yet our shared foundation continues to guide us.
                                </p>
                                <p>
                                    Whether we are educators, engineers, doctors, entrepreneurs, or public servants, one truth remains: <span className="text-primary font-bold italic">CKC made us who we are.</span>
                                </p>
                            </div>

                            <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-gray-100 flex gap-6 italic">
                                <Quote className="w-12 h-12 text-accent shrink-0" />
                                <p className="text-gray-500 text-lg leading-relaxed font-medium">
                                    "Education is not the filling of a pail, but the lighting of a fire — a fire of purpose, character, and truth."
                                    <span className="block mt-4 not-italic font-black text-xs uppercase tracking-widest text-[#0a1128]">
                                        — Rev. Fr. Emmanuel Eze, Catholic Educator
                                    </span>
                                </p>
                            </div>
                        </motion.div>

                        <div className="relative h-[450px] sm:h-[600px] w-full max-w-lg mx-auto lg:max-w-none mt-12 lg:mt-0">
                            {/* Main large image */}
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8 }}
                                className="absolute top-0 left-0 w-[85%] h-[70%] sm:w-[80%] sm:h-[75%] rounded-[2rem] sm:rounded-[3rem] overflow-hidden shadow-2xl border-4 sm:border-8 border-white z-20"
                            >
                                <Image
                                    src={getRandomImage(6)}
                                    alt="Graduation Tradition"
                                    fill
                                    className="object-cover hover:scale-110 transition-transform duration-1000"
                                    unoptimized
                                />
                            </motion.div>

                            {/* Secondary floating image 1 */}
                            <motion.div
                                initial={{ opacity: 0, x: 20 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                transition={{ duration: 0.8, delay: 0.2 }}
                                className="absolute top-[10%] sm:top-[15%] right-0 w-[55%] h-[35%] sm:w-[50%] sm:h-[40%] rounded-[1.5rem] sm:rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white z-30"
                            >
                                <Image
                                    src={getRandomImage(10)}
                                    alt="Class Reunion"
                                    fill
                                    className="object-cover hover:scale-110 transition-transform duration-1000"
                                    unoptimized
                                />
                            </motion.div>

                            {/* Secondary floating image 2 */}
                            <motion.div
                                initial={{ opacity: 0, y: -20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8, delay: 0.4 }}
                                className="absolute bottom-[5%] sm:bottom-0 left-[10%] sm:left-[20%] w-[50%] h-[30%] sm:w-[45%] sm:h-[35%] rounded-[1.5rem] sm:rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white z-30"
                            >
                                <Image
                                    src={getRandomImage(11)}
                                    alt="Brotherhood"
                                    fill
                                    className="object-cover hover:scale-110 transition-transform duration-1000"
                                    unoptimized
                                />
                            </motion.div>

                            {/* Stats Badge */}
                            <motion.div
                                initial={{ scale: 0.8, opacity: 0 }}
                                whileInView={{ scale: 1, opacity: 1 }}
                                transition={{ type: "spring", stiffness: 100, delay: 0.6 }}
                                className="absolute bottom-0 -right-2 sm:bottom-[10%] sm:-right-4 w-32 h-32 sm:w-40 sm:h-40 md:w-52 md:h-52 bg-primary rounded-[1.5rem] sm:rounded-[2.5rem] p-4 sm:p-6 text-white flex flex-col justify-center shadow-2xl border-4 border-white z-40 rotate-6"
                            >
                                <span className="text-2xl sm:text-3xl md:text-5xl font-serif font-bold mb-1 tracking-tighter">44+</span>
                                <span className="text-[7px] sm:text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] opacity-60">Years of</span>
                                <span className="text-[10px] sm:text-xs md:text-sm font-bold uppercase tracking-widest text-accent">Shared Legacy</span>
                            </motion.div>

                            {/* Decorative Background Shape */}
                            <div className="absolute inset-0 bg-accent/5 rounded-[2rem] sm:rounded-[4rem] -rotate-3 scale-105 -z-10" />
                        </div>
                    </div>
                </div>
            </section>

            {/* History of Association */}
            <section className="py-20 md:py-32 bg-slate-50/50">
                <div className="container mx-auto px-4">
                    <div className="text-center max-w-3xl mx-auto mb-16 relative">
                        <div className="inline-flex items-center gap-4 text-accent mb-6">
                            <History className="w-8 h-8" />
                        </div>
                        <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-12">The Association’s Birth</h2>
                    </div>

                    <div className="grid lg:grid-cols-3 gap-12">
                        {/* Column 1: The Stimulus */}
                        <motion.div {...fadeIn} className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all h-full">
                            <span className="inline-block px-3 py-1 bg-red-50 text-red-600 rounded-lg text-[10px] font-black uppercase tracking-widest mb-6">The Stimulus</span>
                            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-6">A Mentor's Legacy</h3>
                            <div className="prose prose-slate text-gray-500 font-medium">
                                <p>
                                    The death of our mentor, <span className="text-primary font-bold">Very Rev. Fr. N. C. Tagbo OON</span>, on 2nd July 2016, provided the stimulus for our existence.
                                </p>
                                <p>
                                    We sponsoring his obituary in the Daily Sun Newspapers and attended his burial in numbers, realizing that the brotherhood he forged in us was stronger than the years apart.
                                </p>
                            </div>
                        </motion.div>

                        {/* Column 2: The Regrouping */}
                        <motion.div {...fadeIn} transition={{ delay: 0.2 }} className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all h-full">
                            <span className="inline-block px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black uppercase tracking-widest mb-6">The regrouping</span>
                            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-6">A Shared Choice</h3>
                            <div className="prose prose-slate text-gray-500 font-medium">
                                <p>
                                    Humphrey Ifeanyi Odiogor, erstwhile Senior Prefect, and Eric Umeh took the lead in reconnecting classmates via GSM.
                                </p>
                                <p>
                                    On <span className="text-primary font-bold">Saturday 29th April 2017</span>, 8 members met at the SWAN Centre, National Stadium, Surulere, for a maiden meeting that gave birth to this association.
                                </p>
                            </div>
                        </motion.div>

                        {/* Column 3: Growth */}
                        <motion.div {...fadeIn} transition={{ delay: 0.4 }} className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all h-full">
                            <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-lg text-[10px] font-black uppercase tracking-widest mb-6">Dynamic Growth</span>
                            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-6">Growing Stronger</h3>
                            <div className="prose prose-slate text-gray-500 font-medium">
                                <p>
                                    Starting with just 9 members, we have since grown to over <span className="text-primary font-bold">85 members</span> on our current WhatsApp platform.
                                </p>
                                <p>
                                    With a class of about 284 students in 1981, our mission continues: to find and reconnect with every brother from that hallowed year.
                                </p>
                            </div>
                        </motion.div>
                    </div>

                    {/* Pioneer Members List - High End Scroll */}
                    <div className="mt-16 md:mt-24 bg-[#0a1128] rounded-[2.5rem] md:rounded-[4rem] p-8 md:p-20 text-white overflow-hidden relative">
                        <div className="absolute top-0 right-0 w-96 h-96 bg-accent opacity-10 rounded-full -mr-48 -mt-48 blur-3xl" />
                        <div className="max-w-4xl mx-auto text-center">
                            <h3 className="text-3xl font-serif font-bold mb-12">The Pioneer Members</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {pioneerMembers.map((member, i) => (
                                    <div key={i} className="py-4 px-6 bg-white/5 rounded-2xl border border-white/10 text-sm font-bold tracking-wide hover:bg-white/10 transition-colors">
                                        {member}
                                    </div>
                                ))}
                            </div>
                            <p className="mt-12 text-xs font-black uppercase tracking-[0.4em] text-white/40">
                                General Secretary: Alex Molokwu
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            {/* CKC Today Section */}
            <section className="py-20 md:py-32">
                <div className="container mx-auto px-4">
                    <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                        <div className="order-2 lg:order-1 relative aspect-video rounded-[2rem] md:rounded-[3rem] overflow-hidden shadow-2xl border-4 md:border-8 border-white ring-1 ring-gray-100">
                            <Image
                                src={getRandomImage(7)}
                                alt="Modern CKC Vision"
                                fill
                                className="object-cover"
                            />
                            <div className="absolute inset-0 bg-primary/20" />
                        </div>

                        <div className="order-1 lg:order-2 space-y-10">
                            <div className="inline-flex items-center gap-4 text-primary">
                                <School className="w-8 h-8" />
                                <span className="text-sm font-black uppercase tracking-widest">CKC Today</span>
                            </div>
                            <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 leading-tight">
                                A Living Legacy of <br />
                                <span className="text-accent italic">Social Mobility.</span>
                            </h2>
                            <div className="prose prose-lg text-gray-600 font-medium leading-relaxed">
                                <p>
                                    Founded in 1933, Christ the King College remains one of Nigeria’s most outstanding institutions. It affords social mobility—bringing together children from all backgrounds to learn and grow as one.
                                </p>
                                <p>
                                    Generations of CKC alumni have demonstration their commitment, funding almost 40% of the work for the new refectory and chapel completed for the 90th Anniversary.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Mission & Objectives */}
            <section className="py-20 md:py-32 bg-[#0a1128] text-white relative overflow-hidden text-center sm:text-left">
                <div className="container mx-auto px-4">
                    <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 relative z-10">
                        <motion.div {...fadeIn} className="space-y-10 md:space-y-12">
                            <div>
                                <h3 className="text-sm font-black uppercase tracking-[0.4em] text-accent mb-6">Our Mission</h3>
                                <p className="text-4xl md:text-5xl font-serif font-bold leading-tight">
                                    To reconnect, inspire, and support one another while giving back.
                                </p>
                            </div>
                            <div className="space-y-8">
                                <div className="flex gap-6 group">
                                    <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center shrink-0 border border-white/10 group-hover:bg-accent transition-all">
                                        <Heart className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <h4 className="text-xl font-serif font-bold mb-2">Foster Lasting Relationships</h4>
                                        <p className="text-white/60 font-medium">Strengthening the bond of brotherhood forged in 1981, wherever we are in the world.</p>
                                    </div>
                                </div>
                                <div className="flex gap-6 group">
                                    <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center shrink-0 border border-white/10 group-hover:bg-accent transition-all">
                                        <Award className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <h4 className="text-xl font-serif font-bold mb-2">Support CKC Initiatives</h4>
                                        <p className="text-white/60 font-medium">Directly contributing to the development and sustainment of the college’s greatness.</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>

                        <motion.div {...fadeIn} transition={{ delay: 0.3 }} className="bg-white/5 rounded-[2.5rem] md:rounded-[4rem] p-8 md:p-16 border border-white/10 backdrop-blur-xl">
                            <h3 className="text-sm font-black uppercase tracking-[0.4em] text-accent mb-12">Leadership & Commitment</h3>
                            <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8 mb-12 p-6 sm:p-8 bg-white/5 rounded-[2rem] md:rounded-[3rem] border border-white/10">
                                <div className="w-24 h-24 bg-accent/20 rounded-[2rem] flex items-center justify-center font-serif text-3xl font-bold italic">RH</div>
                                <div>
                                    <p className="text-2xl font-serif font-bold">Rebbeka Hof</p>
                                    <p className="text-xs font-black uppercase tracking-widest text-accent mt-1">President</p>
                                </div>
                            </div>
                            <p className="text-xl text-white/80 font-medium leading-relaxed italic border-l-4 border-accent pl-8">
                                "Every member serving in these roles does so as a steward of our collective legacy. Their efforts help preserve our bond and ensure the spirit of CKC lives on in action."
                            </p>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Timeline Section */}
            <section className="py-20 md:py-32 bg-white">
                <div className="container mx-auto px-4 text-center">
                    <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900 mb-16 md:mb-20">Our Journey – CKC Alumni 1981 Timeline</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-12 md:gap-8 relative">
                        <div className="hidden md:block absolute top-[28px] left-[10%] right-[10%] h-0.5 bg-gray-100" />
                        {timeline.map((item, i) => (
                            <div key={i} className="relative z-10 space-y-6">
                                <div className="w-14 h-14 bg-white border-4 border-accent rounded-full flex items-center justify-center mx-auto shadow-xl">
                                    <Calendar className="w-6 h-6 text-primary" />
                                </div>
                                <div>
                                    <span className="text-2xl font-serif font-black text-primary">{item.year}</span>
                                    <h4 className="text-lg font-bold text-gray-900 mt-2">{item.title}</h4>
                                    <p className="text-gray-500 text-sm mt-3 px-4">{item.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Final Statement */}
            <section className="py-20 md:py-32 relative overflow-hidden">
                <div className="container mx-auto px-4 text-center">
                    <div className="max-w-4xl mx-auto space-y-10 md:space-y-12">
                        <div className="flex justify-center mb-4">
                            <div className="w-12 h-px bg-accent/30 self-center" />
                            <Quote className="w-12 h-12 text-accent mx-6" />
                            <div className="w-12 h-px bg-accent/30 self-center" />
                        </div>
                        <h3 className="text-4xl md:text-5xl font-serif font-bold text-primary leading-tight italic">
                            “Ad Majorem Dei Gloriam” <br />
                            <span className="text-accent">— To the Greater Glory of God.</span>
                        </h3>
                        <p className="text-xl text-gray-500 font-medium leading-relaxed">
                            Decades after leaving the grounds of Christ the King College, our bond remains strong. Through this platform, we honor our past, celebrate our present, and shape a future rooted in unity, service, and purpose.
                        </p>
                        <div className="pt-10">
                            <NextLink href="/contact" className="inline-block px-12 py-5 bg-primary text-white rounded-full font-black uppercase tracking-[0.3em] shadow-2xl shadow-primary/30 hover:bg-primary/90 transition-all active:scale-95">
                                Join the Brotherhood <ChevronRight className="inline w-5 h-5 ml-2" />
                            </NextLink>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
