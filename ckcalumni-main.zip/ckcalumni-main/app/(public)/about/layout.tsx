import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "About Us",
    description:
        "Learn the story of the CKC Class of 1981 — from our formative years at Christ the King College, Onitsha, to four decades of brotherhood, achievement, and service. Discover the legacy of Very Rev. Fr. N.C. Tagbo OON.",
    openGraph: {
        title: "About Us | CKC Class of 1981",
        description:
            "Discover the rich history and enduring legacy of the CKC Class of 1981. Formed in Onitsha, bound by brotherhood across the globe.",
        url: "/about",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 Logo" }],
    },
    twitter: {
        title: "About Us | CKC Class of 1981",
        description:
            "Discover the rich history and enduring legacy of the CKC Class of 1981.",
    },
};

export default function AboutLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
