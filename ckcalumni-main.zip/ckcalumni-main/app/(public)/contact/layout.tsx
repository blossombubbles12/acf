import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Contact Us",
    description:
        "Get in touch with the CKC Class of 1981 Alumni Association. Reach the class secretary, welfare officer, or join our official communication channels.",
    openGraph: {
        title: "Contact Us | CKC Class of 1981",
        description:
            "Reach out to the CKC Class of 1981 Alumni Association — class secretary, welfare, and official channels.",
        url: "/contact",
        images: [{ url: "/ckclogo.png", alt: "CKC Class of 1981 Logo" }],
    },
};

export default function ContactLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
