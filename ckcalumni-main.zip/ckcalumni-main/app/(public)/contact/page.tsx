"use client";

import Image from "next/image";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";

export default function ContactPage() {
    const { getRandomImage } = useCloudinaryPool();
    return (
        <div className="bg-white min-h-screen">
            {/* Hero Section */}
            <section className="relative pt-40 pb-24 bg-[#0a1128] text-white">
                <div className="absolute inset-0 z-0 opacity-20">
                    <Image
                        src={getRandomImage(2)}
                        alt="Contact"
                        fill
                        className="object-cover"
                    />
                </div>
                <div className="container mx-auto px-4 relative z-10 text-center">
                    <span className="inline-block px-3 py-1.5 sm:px-4 sm:py-2 rounded-full bg-accent/20 text-accent text-[9px] sm:text-[10px] font-black uppercase tracking-[0.3em] sm:tracking-[0.4em] mb-4 sm:mb-6 border border-accent/20">
                        Get In Touch
                    </span>
                    <h1 className="text-4xl sm:text-5xl md:text-7xl font-serif font-bold mb-4 sm:mb-6 italic leading-tight">Contact <span className="font-light not-italic">Us</span></h1>
                    <p className="text-sm sm:text-base md:text-lg text-white/60 max-w-2xl mx-auto font-medium leading-relaxed">
                        We'd love to hear from you. Reach out for inquiries, reunion details, or just to say hello to the secretariat.
                    </p>
                </div>
            </section>

            <section className="py-12 sm:py-20">
                <div className="container mx-auto px-4">
                    <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-0 md:gap-12 bg-white rounded-3xl md:rounded-2xl shadow-xl overflow-hidden border border-gray-100">

                        {/* Contact Info */}
                        <div className="bg-slate-50 p-8 sm:p-10 md:p-14 space-y-8">
                            <div>
                                <h3 className="text-xl sm:text-2xl font-serif font-bold text-primary mb-4 sm:mb-6">Contact Information</h3>
                                <p className="text-sm sm:text-base text-gray-600 mb-6 sm:mb-8">
                                    Reach out to the executive committee or support team using the details below.
                                </p>
                            </div>

                            <div className="space-y-6">
                                <div className="flex items-start gap-4">
                                    <div className="w-10 h-10 bg-white shadow-sm rounded-full flex items-center justify-center text-accent shrink-0">
                                        <MapPin className="w-5 h-5" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">Address</h4>
                                        <p className="text-gray-600">Christ the King College,<br />Onitsha, Anambra State, Nigeria</p>
                                    </div>
                                </div>

                                <div className="flex items-start gap-4">
                                    <div className="w-10 h-10 bg-white shadow-sm rounded-full flex items-center justify-center text-accent shrink-0">
                                        <Mail className="w-5 h-5" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">Email</h4>
                                        <a href="mailto:info@ckcalumniclass1981.org" className="text-gray-600 hover:text-primary transition-colors">
                                            info@ckcalumniclass1981.org
                                        </a>
                                    </div>
                                </div>

                                <div className="flex items-start gap-4">
                                    <div className="w-10 h-10 bg-white shadow-sm rounded-full flex items-center justify-center text-accent shrink-0">
                                        <Phone className="w-5 h-5" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">Phone</h4>
                                        <p className="text-gray-600">+234 800 000 0000</p>
                                        <p className="text-gray-500 text-sm">(Mon-Fri, 9am - 5pm)</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Form */}
                        <div className="p-8 sm:p-10 md:p-14">
                            <h3 className="text-xl sm:text-2xl font-serif font-bold text-primary mb-4 sm:mb-6">Send us a Message</h3>
                            <form className="space-y-4 sm:space-y-6" onSubmit={(e) => e.preventDefault()}>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                                    <div className="space-y-1 sm:space-y-2">
                                        <label className="text-xs sm:text-sm font-medium text-gray-700">First Name</label>
                                        <input
                                            type="text"
                                            className="w-full px-4 py-2.5 sm:py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm"
                                            placeholder="John"
                                        />
                                    </div>
                                    <div className="space-y-1 sm:space-y-2">
                                        <label className="text-xs sm:text-sm font-medium text-gray-700">Last Name</label>
                                        <input
                                            type="text"
                                            className="w-full px-4 py-2.5 sm:py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm"
                                            placeholder="Doe"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1 sm:space-y-2">
                                    <label className="text-xs sm:text-sm font-medium text-gray-700">Email Address</label>
                                    <input
                                        type="email"
                                        className="w-full px-4 py-2.5 sm:py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm"
                                        placeholder="john@example.com"
                                    />
                                </div>

                                <div className="space-y-1 sm:space-y-2">
                                    <label className="text-xs sm:text-sm font-medium text-gray-700">Message</label>
                                    <textarea
                                        rows={4}
                                        className="w-full px-4 py-2.5 sm:py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-sm"
                                        placeholder="How can we help you?"
                                    ></textarea>
                                </div>

                                <button
                                    type="submit"
                                    className="w-full py-3.5 sm:py-4 bg-primary text-white rounded-lg font-bold hover:bg-primary/90 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-1 text-sm sm:text-base"
                                >
                                    Send Message <Send className="w-4 h-4" />
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
