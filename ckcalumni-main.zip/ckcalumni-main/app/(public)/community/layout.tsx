import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Community",
    description:
        "Join the CKC Class of 1981 digital alumni directory. Connect with brothers across the globe — search by profession, location, or graduation year.",
    openGraph: {
        title: "Community | CKC Class of 1981",
        description:
            "The CKC Class of 1981 alumni directory — reconnect with brothers worldwide.",
        url: "/community",
        images: [{ url: "/ckclogo.png", alt: "CKC Community" }],
    },
};

export default function CommunityLayout({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
