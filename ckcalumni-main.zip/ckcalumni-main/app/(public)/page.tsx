"use client";

import Image from "next/image";
import Link from "next/link";
import {
  Users,
  Calendar,
  Heart,
  Award,
  Globe,
  Quote,
  ChevronRight,
  Search,
  BookOpen,
  MessageSquare,
  Image as ImageIcon,
  FileText,
  CheckSquare,
  Trophy,
  ArrowRight,
  MapPin,
  Briefcase
} from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { EventsShowcase } from "@/components/home/EventsShowcase";
import { PostsShowcase } from "@/components/home/PostsShowcase";
import { GalleryShowcase } from "@/components/home/GalleryShowcase";
import { VideoSection } from "@/components/home/VideoSection";
import { HeroCarousel } from "@/components/home/HeroCarousel";
import { useCloudinaryPool } from "@/hooks/useCloudinaryPool";

export default function Home() {
  const { getRandomImage } = useCloudinaryPool();
  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6 }
  };

  const stats = [
    { label: "Since 1981", value: "44 Years", icon: Calendar },
    { label: "Verified Alumni", value: "150+", icon: Users },
    { label: "Shared Memories", value: "1,200+", icon: ImageIcon },
    { label: "Global Reach", value: "200 Members", icon: Globe },
  ];

  const features = [
    {
      title: "Mentorship & Support Hub",
      desc: "Offer guidance to younger CKC generations or find support from the brotherhood.",
      icon: Heart,
      color: "bg-red-50 text-red-600"
    },
    {
      title: "Live Updates",
      desc: "Class updates, welfare notices, and community-driven news on your dashboard.",
      icon: MessageSquare,
      color: "bg-blue-50 text-blue-600"
    },
    {
      title: "Archive Library",
      desc: "Access class records, event reports, and important historical documents.",
      icon: FileText,
      color: "bg-amber-50 text-amber-600"
    },
    {
      title: "Polls & feedback",
      desc: "Vote on class decisions and projects that shape our collective direction.",
      icon: CheckSquare,
      color: "bg-emerald-50 text-emerald-600"
    },
    {
      title: "Media Gallery",
      desc: "Browse shared photos, throwback memories, and reunion videos.",
      icon: ImageIcon,
      color: "bg-purple-50 text-purple-600"
    },
    {
      title: "Directory of Brothers",
      desc: "Reconnect with classmates. View bios, professions, and contact details.",
      icon: Users,
      color: "bg-sky-50 text-sky-600"
    },
    {
      title: "Private Messaging",
      desc: "Engage in meaningful conversations through secure feed and direct messaging.",
      icon: MessageSquare,
      color: "bg-indigo-50 text-indigo-600"
    },
    {
      title: "Events Hub",
      desc: "Stay informed on regional meetups, anniversaries, and upcoming reunions.",
      icon: Calendar,
      color: "bg-rose-50 text-rose-600"
    },
  ];

  const pillars = [
    { title: "Brotherhood", desc: "No matter where life has taken us, we remain brothers — always looking out for one another." },
    { title: "Loyalty to CKC", desc: "We stay committed to honoring its legacy and preserving its name with pride." },
    { title: "Shared Memories", desc: "From morning assemblies to inter-house sports, our experiences are etched in time." },
    { title: "Global Network", desc: "From Lagos to London — we are everywhere, keeping our bond alive regardless of distance." },
  ];

  const executives = [
    { name: "Chibuzor Oko", role: "President" },
    { name: "Emeka Onwuelo", role: "Vice President" },
    { name: "Ralph Oranyelu Ezeudu", role: "Treasurer" },
    { name: "Alex Molokwu", role: "General Secretary" },
    { name: "Chris Onuigbo", role: "Financial Secretary" },
    { name: "Tony Ezenwaka", role: "Publicity Secretary" },
    { name: "Dan Onyenakorom", role: "Welfare Officer" },
    { name: "John Aroh", role: "Legal Officer" },
  ];

  const reunionCommittee = [
    { name: "Dr Ray Onwuelo", role: "Chairman" },
    { name: "Dr (Engr) Vincent Amu", role: "Treasurer/Publicity & Media" },
    { name: "Chief Eric Ume", role: "Program" },
    { name: "Navy Captain Chuka Stanley Igwe (Rtd)", role: "Security & Logistics" },
    { name: "Emmanuel Anaenugwu", role: "Food & Entertainment" },
  ];

  return (
    <div className="bg-white overflow-hidden">
      {/* 1. HERO SECTION - Creative Slider */}
      <HeroCarousel />

      {/* 2. STATS BAR */}
      <section className="relative z-20 py-10 bg-white border-b border-gray-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-4 divide-x-0 md:divide-x divide-gray-100">
            {stats.map((stat, i) => (
              <div key={i} className="text-center md:px-8">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-2">{stat.label}</p>
                <p className="text-3xl md:text-4xl font-serif font-bold text-primary">{stat.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEW: VIDEO TEASER SECTION */}
      <VideoSection />

      {/* 3. INTRODUCTION SECTION */}
      <section className="py-16 md:py-32">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-20 items-center">
            <motion.div {...fadeIn}>
              <div className="inline-flex items-center gap-4 text-accent mb-6 md:mb-8">
                <span className="h-px w-12 bg-accent/30" />
                <span className="text-xs font-black uppercase tracking-[0.3em]">Our Family</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-6xl font-serif font-bold text-gray-900 leading-tight mb-6 md:mb-8">
                Reuniting Brotherhood. <br />
                <span className="text-primary italic font-light">Honoring Legacy.</span>
              </h2>
              <div className="space-y-4 text-base sm:text-lg text-gray-600 font-medium leading-relaxed">
                <p>
                  The CKC Alumni 1981 is more than just a graduating class — we are a family built on shared experiences, brotherhood, and timeless memories.
                </p>
                <p>
                  This platform serves to reconnect us, celebrate our milestones, and drive initiatives that give back to our alma mater and communities.
                </p>
              </div>
              <div className="pt-8 flex flex-wrap gap-4">
                <Link href="/about" className="inline-flex items-center gap-2 group text-primary font-black uppercase tracking-widest text-xs">
                  History of CKC <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
                <span className="text-gray-200">|</span>
                <Link href="#executives" className="inline-flex items-center gap-2 group text-primary font-black uppercase tracking-widest text-xs">
                  Executive Committee <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </motion.div>

            <div className="relative aspect-[4/5] sm:aspect-[4/5] rounded-[2rem] md:rounded-[2.5rem] overflow-hidden group">
              <Image
                src={getRandomImage(2)}
                alt="Class Photo"
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-1000"
                unoptimized
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
              <div className="absolute bottom-6 left-6 sm:bottom-10 sm:left-10 text-white">
                <p className="text-2xl sm:text-3xl font-serif font-bold italic mb-1">Class of 1981</p>
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white/60">44 Years & Counting</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEW: EVENTS SHOWCASE */}
      <EventsShowcase />

      {/* 4. PILLARS SECTION */}
      <section className="py-24 bg-navy text-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6">Our Pillars of Connection</h2>
            <p className="text-white/60 font-medium leading-relaxed">
              At CKC Alumni 1981, our bond is more than a memory — it's a living force rooted in shared values. Here's what continues to bring us together.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {pillars.map((pillar, i) => (
              <motion.div
                key={i}
                {...fadeIn}
                transition={{ delay: i * 0.1 }}
                className="p-10 rounded-[3rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-all group"
              >
                <div className="w-12 h-12 bg-accent/20 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-accent group-hover:text-primary transition-all">
                  <Trophy className="w-6 h-6 text-accent group-hover:text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-4">{pillar.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed font-medium">{pillar.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. DIRECTORY CALLOUT */}
      <section className="py-16 sm:py-24 relative">
        <div className="container mx-auto px-4">
          <div className="bg-slate-50 rounded-[2.5rem] sm:rounded-[4rem] p-6 sm:p-10 md:p-20 flex flex-col lg:flex-row items-center gap-10 md:gap-16 border border-gray-100">
            <div className="lg:w-1/2 space-y-6 sm:space-y-10 w-full">
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-gray-900">Explore the Brotherhood Network</h2>
              <p className="text-gray-600 text-base sm:text-lg leading-relaxed font-medium">
                Reconnect with fellow members across the globe. Our dynamic alumni directory allows you to search by name, profession, or location. Whether looking to catch up or collaborate, this is your gateway.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/community" className="px-6 sm:px-8 py-3.5 sm:py-4 bg-primary text-white rounded-full font-bold shadow-xl shadow-primary/20 flex items-center gap-2 hover:bg-primary/90 transition-all">
                  View Members <ChevronRight className="w-4 h-4" />
                </Link>
                <button className="px-6 sm:px-8 py-3.5 sm:py-4 bg-white text-primary border border-gray-200 rounded-full font-bold hover:bg-gray-50 transition-all">
                  Search Directory
                </button>
              </div>
            </div>
            <div className="lg:w-1/2 w-full grid grid-cols-2 gap-4">
              <div className="space-y-4 pt-0 sm:pt-12">
                <div className="p-6 bg-white rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-sky-50 rounded-2xl flex items-center justify-center text-sky-600"><MapPin className="w-6 h-6" /></div>
                  <div><p className="font-bold text-gray-900">Lagos</p><p className="text-xs text-gray-400">42 Members</p></div>
                </div>
                <div className="p-6 bg-white rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600"><MapPin className="w-6 h-6" /></div>
                  <div><p className="font-bold text-gray-900">London</p><p className="text-xs text-gray-400">18 Members</p></div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="p-6 bg-white rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600"><Briefcase className="w-6 h-6" /></div>
                  <div><p className="font-bold text-gray-900">Executives</p><p className="text-xs text-gray-400">Professionals</p></div>
                </div>
                <div className="p-6 bg-white rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600"><MapPin className="w-6 h-6" /></div>
                  <div><p className="font-bold text-gray-900">USA</p><p className="text-xs text-gray-400">25 Members</p></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. WHAT YOU CAN DO GRID */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto mb-20">
            <span className="text-xs font-black uppercase tracking-[0.4em] text-accent mb-6 block">What You Can Do</span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Member Features & Benefits</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                {...fadeIn}
                transition={{ delay: i * 0.05 }}
                className="group p-8 rounded-[2rem] bg-white border border-gray-100 hover:border-primary hover:shadow-2xl hover:shadow-primary/5 transition-all text-left"
              >
                <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed font-medium line-clamp-2">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* NEW: POSTS SHOWCASE */}
      <PostsShowcase />

      {/* 7. FR TAGBO LEGACY SPOTLIGHT */}
      <section className="py-16 sm:py-24 md:py-32 bg-[#FAF9F6] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[50%] h-full bg-slate-50/50 -skew-x-12 translate-x-1/2" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-20 items-center">
            <div className="relative pb-16 sm:pb-20">
              <div className="aspect-[4/5] rounded-[2rem] sm:rounded-[3rem] overflow-hidden shadow-2xl border-4 sm:border-8 border-white ring-1 ring-gray-100">
                <Image
                  src="/Rev fada Tagbo.jpg"
                  alt="Reverend Father N.C Tagbo"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-2 left-0 right-0 sm:-bottom-10 sm:-left-10 bg-white p-6 sm:p-10 rounded-[1.5rem] sm:rounded-[2rem] shadow-2xl border border-gray-50 mx-2 sm:mx-0 sm:max-w-sm">
                <Quote className="w-8 h-8 sm:w-12 sm:h-12 text-accent opacity-20 mb-3" />
                <p className="text-gray-500 font-serif text-sm sm:text-lg leading-relaxed italic">
                  "A beacon of discipline and character for every gentleman of CKC."
                </p>
              </div>
            </div>

            <div className="space-y-6 sm:space-y-10">
              <div className="inline-flex items-center gap-4 text-primary">
                <span className="text-[10px] font-black uppercase tracking-[0.4em]">Legacy Spotlight</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-6xl font-serif font-bold text-gray-900 leading-tight">
                The man Reverend Father <br />
                <span className="text-accent italic">N.C Tagbo OON.</span>
              </h2>
              <div className="prose prose-base sm:prose-lg text-gray-600 font-medium leading-relaxed">
                <p>
                  Nicholas Chukwuemeka Tagbo was born on 21st August 1929. A CKC graduate himself (Class of 1949), he dedicated his life to education and service.
                </p>
                <p>
                  His leadership at Christ the King College shaped generations of men including the class of 1981, instilling values that have lasted over four decades.
                </p>
              </div>
              <Link href="/about" className="inline-flex items-center gap-3 px-7 sm:px-8 py-3.5 sm:py-4 bg-primary text-white rounded-full font-bold shadow-xl shadow-primary/20 hover:scale-105 transition-all">
                View Full Story <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* NEW: GALLERY SHOWCASE */}
      <GalleryShowcase />

      {/* 8. EXECUTIVES SECTION */}
      <section id="executives" className="py-24 md:py-32 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
            <div className="max-w-2xl">
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-accent mb-6 block">Our Leadership</span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Class of 1981 Executives</h2>
            </div>
            <p className="text-gray-400 font-medium italic text-right hidden md:block">
              Guiding the brotherhood into the future.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
            {executives.map((exec, i) => (
              <motion.div
                key={i}
                {...fadeIn}
                transition={{ delay: i * 0.05 }}
                className="p-8 rounded-[2rem] bg-white border border-gray-100 shadow-sm hover:shadow-xl hover:border-accent transition-all text-center flex flex-col items-center"
              >
                <div className="w-20 h-20 bg-primary/5 rounded-[1.5rem] flex items-center justify-center mb-6 font-serif text-2xl font-bold text-primary">
                  {exec.name[0]}
                </div>
                <h4 className="text-lg font-black text-gray-900 mb-1">{exec.name}</h4>
                <p className="text-xs font-bold text-accent uppercase tracking-widest">{exec.role}</p>
              </motion.div>
            ))}
          </div>

          {/* Reunion Committee Sub-header */}
          <div className="pt-20 border-t border-gray-100">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8 text-center sm:text-left">
              <div className="max-w-2xl">
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-accent mb-6 block">Reunion 2025</span>
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">Second Grand Reunion Committee</h2>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              {reunionCommittee.map((exec, i) => (
                <motion.div
                  key={i}
                  {...fadeIn}
                  transition={{ delay: i * 0.05 }}
                  className="p-6 rounded-[1.5rem] bg-slate-50 border border-gray-100 hover:bg-white transition-all"
                >
                  <h4 className="text-sm font-black text-gray-900 mb-1">{exec.name}</h4>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-normal">{exec.role}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 9. FINAL CTA SECTION */}
      <section className="py-24 relative overflow-hidden bg-navy text-white">
        <div className="absolute inset-0 z-0">
          <Image
            src={getRandomImage(4)}
            alt="Final Call"
            fill
            className="object-cover opacity-10"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <div className="max-w-4xl mx-auto space-y-12">
            <Quote className="w-20 h-20 text-accent opacity-20 mx-auto" />
            <h2 className="text-4xl md:text-6xl font-serif font-bold leading-tight">
              Reconnect & Remember. <br />
              <span className="text-accent italic font-light">The Walk Down Memory Lane.</span>
            </h2>
            <p className="text-xl text-white/50 font-medium leading-relaxed">
              Relive the moments that made us brothers. From class photos and stories to signature events, take a walk down memory lane and rediscover the faces, friendships, and milestones that shaped our journey.
            </p>
            <div className="pt-10 flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link href="/media" className="px-12 py-5 bg-accent text-white rounded-full font-black uppercase tracking-[0.2em] shadow-2xl shadow-accent/20 hover:scale-110 active:scale-95 transition-all text-sm">
                Visit the Photo Gallery
              </Link>
              <Link href="/about" className="px-12 py-5 border border-white/20 rounded-full font-black uppercase tracking-[0.2em] hover:bg-white/10 transition-all text-sm">
                Full Story of Father Tagbo
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
