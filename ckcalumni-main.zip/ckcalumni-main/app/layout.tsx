import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
});

const playfair = Playfair_Display({
  variable: "--font-serif",
  subsets: ["latin"],
});

const siteUrl = "https://ckcalumni.vercel.app";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "CKC Class of 1981 Alumni Association",
    template: "%s | CKC Class of 1981",
  },
  description:
    "The official alumni platform of the Christ the King College (CKC) Class of 1981. A global network of excellence, brotherhood, and shared legacy since 1981.",
  keywords: [
    "CKC", "Christ the King College", "CKC Class of 1981", "CKC Alumni",
    "Onitsha", "Nigerian alumni", "brotherhood", "CKC reunion",
  ],
  authors: [{ name: "CKC Class of 1981 Alumni Association" }],
  creator: "CKC Class of 1981",
  publisher: "CKC Class of 1981 Alumni Association",
  openGraph: {
    type: "website",
    locale: "en_NG",
    url: siteUrl,
    siteName: "CKC Class of 1981",
    title: "CKC Class of 1981 Alumni Association",
    description:
      "The official alumni platform of the Christ the King College (CKC) Class of 1981. Brotherhood, excellence, and a legacy that spans decades.",
    images: [
      {
        url: "/ckclogo.png",
        width: 800,
        height: 800,
        alt: "CKC Class of 1981 Logo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "CKC Class of 1981 Alumni Association",
    description:
      "The official alumni platform of the Christ the King College (CKC) Class of 1981.",
    images: ["/ckclogo.png"],
  },
  icons: {
    icon: [
      { url: "/icon.png", type: "image/png" },
    ],
    apple: [
      { url: "/icon.png" },
    ],
    shortcut: "/icon.png",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} ${playfair.variable} antialiased font-sans flex flex-col min-h-screen`}
      >
        {children}
      </body>
    </html>
  );
}
