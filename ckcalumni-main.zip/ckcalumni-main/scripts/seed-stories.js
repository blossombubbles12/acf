const fs = require('fs');
const path = require('path');
const { neon } = require('@neondatabase/serverless');

const envPath = path.join(__dirname, '../.env.local');
const env = fs.readFileSync(envPath, 'utf8');
const dbUrlMatch = env.match(/DATABASE_URL=['"]?(.+?)['"]?\s*$/m);
const dbUrl = dbUrlMatch ? dbUrlMatch[1] : null;

if (!dbUrl) {
    console.error("DATABASE_URL not found in .env.local");
    process.exit(1);
}

const sql = neon(dbUrl);

async function seedPosts() {
    try {
        console.log("Seeding sample alumni stories/posts...");

        const admin = await sql`SELECT id FROM admins LIMIT 1`;
        if (admin.length === 0) {
            console.error("No admin found. Please create an admin first.");
            process.exit(1);
        }
        const adminId = admin[0].id;

        const stories = [
            {
                title: "CKC Class of 1981: 40 Years of Excellence",
                content: "From the hallowed halls of Christ the King College, Onitsha, the class of 1981 has emerged as a beacon of leadership. This month, we reflect on our journey and the impact our brothers are making globally.",
                category: "news",
                image_url: "https://images.unsplash.com/photo-1523580494863-6f3031224c94?q=80&w=2000"
            },
            {
                title: "Brotherhood Beyond Borders",
                content: "Our diaspora chapters in London and Houston continue to show the true spirit of CKC. Read about the recent medical outreach sponsored by our brothers in Europe.",
                category: "announcement",
                image_url: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?q=80&w=2000"
            },
            {
                title: "Restoring the Great Hall: A Class Project",
                content: "The 1981 set is proud to announce the commencement of the renovation project for the CKC Main Hall. This legacy project aims to provide current students with world-class facilities.",
                category: "news",
                image_url: "https://images.unsplash.com/photo-1541829070764-84a7d30dee3f?q=80&w=2000"
            }
        ];

        for (const story of stories) {
            await sql`
                INSERT INTO posts (title, content, category, image_url, author_id)
                VALUES (${story.title}, ${story.content}, ${story.category}, ${story.image_url}, ${adminId})
            `;
        }

        console.log("Stories seeded successfully!");
        process.exit(0);
    } catch (err) {
        console.error("Error seeding stories:", err);
        process.exit(1);
    }
}

seedPosts();
