const fs = require('fs');
const path = require('path');
const { neon } = require('@neondatabase/serverless');

const envPath = path.join(__dirname, '../.env.local');
const env = fs.readFileSync(envPath, 'utf8');
const dbUrlMatch = env.match(/DATABASE_URL=['"]?(.+?)['"]?\s*$/m);
const dbUrl = dbUrlMatch ? dbUrlMatch[1] : null;

if (!dbUrl) {
    console.error("DATABASE_URL not found in .env.local");
    process.exit(1);
}

const sql = neon(dbUrl);

async function seed() {
    try {
        console.log("Seeding sample alumni members...");

        const alumni = [
            {
                full_name: "Chief Emeka Okoro",
                email: "emeka.okoro@example.com",
                phone: "+234 803 123 4567",
                occupation: "CEO & Chairman",
                industry: "Logistics & Supply Chain",
                location: "Lagos, Nigeria",
                cohort: "1981",
                biography: "A veteran in the logistics industry with over 30 years of experience. Passionate about class welfare and digital transformation.",
                status: "active",
                is_visible: true
            },
            {
                full_name: "Dr. Chidi Nwachukwu",
                email: "chidi.md@example.com",
                phone: "+44 7700 900123",
                occupation: "Consultant Cardiologist",
                industry: "Healthcare",
                location: "London, UK",
                cohort: "1981",
                biography: "Leading cardiology consultant in the UK. Founding member of the CKC London Alumni branch.",
                status: "active",
                is_visible: true
            },
            {
                full_name: "Engr. Tunde Adeboye",
                email: "t.adeboye@example.com",
                phone: "+1 713 555 0199",
                occupation: "Oil & Gas Consultant",
                industry: "Energy",
                location: "Houston, USA",
                cohort: "1981",
                biography: "Expert in deepwater drilling and energy transition. Always ready to mentor younger engineers from our alma mater.",
                status: "active",
                is_visible: true
            },
            {
                full_name: "Barr. Ifeanyi Obiorah",
                email: "ifeanyi.law@example.com",
                phone: "+234 812 345 6789",
                occupation: "Principal Partner",
                industry: "Legal Services",
                location: "Enugu, Nigeria",
                cohort: "1981",
                biography: "Specializing in corporate law and constitutional matters. Served as the Class Secretary for several terms.",
                status: "active",
                is_visible: true
            }
        ];

        for (const person of alumni) {
            await sql`
                INSERT INTO members (full_name, email, phone, occupation, industry, location, cohort, biography, status, is_visible)
                VALUES (
                    ${person.full_name}, ${person.email}, ${person.phone}, 
                    ${person.occupation}, ${person.industry}, ${person.location}, 
                    ${person.cohort}, ${person.biography}, ${person.status}, ${person.is_visible}
                )
                ON CONFLICT (email) DO NOTHING
            `;
        }

        console.log("Seeding sample events...");

        const events = [
            {
                title: "CKC Class of '81 Grand Reunion 2026",
                description: "The ultimate gathering of the legendary 1981 set. A weekend of nostalgia, networking, and celebration of our shared heritage at Christ the King College, Onitsha.",
                date: "2026-12-15",
                time: "10:00 AM",
                location: "CKC Auditorium, Onitsha",
                status: "published",
                image_url: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=2000"
            },
            {
                title: "Regional Meetup: Lagos Chapter",
                description: "Join fellow Lagos-based brothers for an evening of networking and discussion on upcoming class projects.",
                date: "2026-03-20",
                time: "06:00 PM",
                location: "Radisson Blu, Victoria Island, Lagos",
                status: "published",
                image_url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2000"
            },
            {
                title: "40th Anniversary Gala (Retro)",
                description: "Celebrating four decades of brotherhood. This past event marked our 40th year since leaving the great walls of CKC.",
                date: "2021-12-20",
                time: "07:00 PM",
                location: "Online (Global Zoom Event)",
                status: "published",
                image_url: "https://images.unsplash.com/photo-1472653423608-ee242fd5afad?q=80&w=2000"
            }
        ];

        for (const evt of events) {
            await sql`
                INSERT INTO events (title, description, date, time, location, status, image_url)
                VALUES (${evt.title}, ${evt.description}, ${evt.date}, ${evt.time}, ${evt.location}, ${evt.status}, ${evt.image_url})
            `;
        }

        console.log("Seeding completed successfully!");
        process.exit(0);
    } catch (err) {
        console.error("Error seeding data:", err);
        process.exit(1);
    }
}

seed();
