"use client";

import { useState, useEffect } from "react";
import { transformCloudinary } from "@/lib/cloudinary-client";

/**
 * A hook that maintains a pool of random images from Cloudinary.
 * Designed to minimize API calls by caching the result in session storage.
 * Falls back to real Cloudinary-hosted images in case the API is unavailable.
 */

const CACHE_KEY = "ckc_media_pool_v2";
const CLOUD = "dtw0ajpwa";
const cld = (id: string) => `https://res.cloudinary.com/${CLOUD}/image/upload/${id}`;
const FALLBACK_POOL = [
    cld("DSC_2000_utsl1t"),
    cld("DSC_1992_cajnlm"),
    cld("DSC_2143_bnj7d6"),
];

export function useCloudinaryPool(count: number = 10) {
    const [images, setImages] = useState<string[]>(FALLBACK_POOL);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPool = async () => {
            // Check session storage first to save API tokens
            try {
                const cached = sessionStorage.getItem(CACHE_KEY);
                if (cached) {
                    const parsed = JSON.parse(cached);
                    if (Array.isArray(parsed) && parsed.length > 0) {
                        setImages(parsed);
                        setLoading(false);
                        return;
                    }
                }
            } catch (e) {
                // sessionStorage not available (SSR edge case)
            }

            try {
                const res = await fetch("/api/media/featured");
                if (!res.ok) throw new Error(`API ${res.status}`);
                const data = await res.json();

                if (Array.isArray(data) && data.length > 0) {
                    const imageUrls = data
                        .filter((item: any) => item.resource_type === "image" && item.secure_url)
                        .map((item: any) => item.secure_url);

                    if (imageUrls.length > 0) {
                        setImages(imageUrls);
                        try {
                            sessionStorage.setItem(CACHE_KEY, JSON.stringify(imageUrls));
                        } catch (e) { /* storage full */ }
                    }
                }
            } catch (err) {
                // Keep the FALLBACK_POOL already set as initial state
                console.warn("Cloudinary pool: using fallback images", err);
            } finally {
                setLoading(false);
            }
        };

        fetchPool();
    }, []);

    // Helper to get a deterministic image from the pool based on an index
    const getRandomImage = (index: number = 0) => {
        const rawUrl = images[index % images.length];
        return transformCloudinary(rawUrl);
    };

    return { images, getRandomImage, loading };
}
